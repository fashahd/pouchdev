<!-- Form horizontal -->
<br>
<br>
<div class="content">
	<div class="panel panel-flat">
		<div id="notfound">
			<div class="row">
				<div class="col-md-12">
					<div class="text-center content-group">
						<h1 class="error-title">404</h1>
						<h5>Oops, an error has occurred. Page not found!</h5>
					</div>
				<!-- /error title -->
				</div>
			</div>
		</div>
	</div>
</div>